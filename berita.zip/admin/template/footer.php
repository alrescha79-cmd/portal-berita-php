  <footer class="main-footer">
      <strong>Copyright &copy; 2023</strong>
      All rights reserved. | TA Pemrograman WEB</a>

      <div class="float-right d-none d-sm-inline-block">
          <b>2021</b> C
      </div>
  </footer>
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->

  <!-- jQuery -->
  <script src="../assets/js/be/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../assets/js/be/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE -->
  <script src="../assets/js/be/adminlte.js"></script>

  <script src="../assets/js/be/bs-custom-file-input/bs-custom-file-input.min.js"></script>

  <!-- OPTIONAL SCRIPTS -->
  <script src="../assets/js/be/chart.js/Chart.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <!-- <script src="../assets/js/be/demo.js"></script> -->
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <!-- <script src="../assets/js/be/pages/dashboard3.js"></script> -->
  
  </body>

  </html>
